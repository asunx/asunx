*************************************************************************************************

		2-49 SkyLay Fast Windows 1.0

Windows makes a small delay on the startup, for letting other apps to load parallel with Windows.
With this app, you can disable the delay - so Windows will be starting up much faster.
You can also roll back the changes with one click.

*************************************************************************************************